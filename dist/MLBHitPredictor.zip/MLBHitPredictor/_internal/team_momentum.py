def get_team_momentum(team_id):
    return {'recent_runs': 5.8, 'recent_win_pct': 0.600}
