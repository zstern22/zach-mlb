def get_lineup_context(player_name, team, date):
    return {'before_obp': 0.340, 'after_obp': 0.355}
